#include "bank_account.h"

bank_account::bank_account() {
	first_name = "NONE";
	last_nafme = "NONE";
	email = "NONE";
	password = "NONE";
	id_number = "NONE";
	afm = "NONE";
	birth_date = "00/00/0000";
	income = 0;
	ects = 0;
	remember = false;
}
bank_account::bank_account(std::string f_nafme, std::string l_nafme, std::string ac_email,std::string pass, std::string id, std::string ar_m, std::string b_date, int sem, int ect,bool rem) {

	first_name = f_nafme;
	last_nafme = l_nafme;
	email = ac_email;
	password = pass;
	id_number = id;
	afm = ar_m;
	birth_date = b_date;
	income = sem;
	ects = ect;
	remember = rem;

}
