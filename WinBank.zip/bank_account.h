#pragma once
#include <string>
class bank_account
{
public:
	std::string first_name;
	std::string last_nafme;
	std::string email;
	std::string password;
	std::string id_number;
	std::string afm;
	std::string birth_date;
	bool remember;
	
	int income;
	int ects;
	bank_account();
	bank_account(std::string f_nafme, std::string l_nafme, std::string ac_email,std::string pass, std::string id, std::string ar_m, std::string b_date, int sem, int ect,bool rem);
	
};

