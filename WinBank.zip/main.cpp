﻿#include <iostream>
#include <windows.h>
#include <fstream>
#include <string>
#include <conio.h>
#include "bank_account.h"
#include "subject.h"
#include <vector>
#include <algorithm>
using namespace std;

const int login_button_width = 12;
const int login_button_height = 3;

const int form_width = 36;
const int form_height = 3;

char login_button[login_button_height][login_button_width];
char signup_button[login_button_height][login_button_width];
char form[form_height][form_width];

const int KEY_UP = 72;
const int KEY_DOWN = 80;
const int KEY_LEFT = 75;
const int KEY_RIGHT = 77;

void save_accounts(const vector<bank_account>& bank_accounts);
void get_form() {
    int i, j;
    std::ifstream inputfile("form.txt");
    if (inputfile.is_open()) {
        std::string line;
        int line_number = 0;

        while (getline(inputfile, line) && line_number < form_height) {
            for (j = 0; j < line.length() && j < form_width; j++) {
                form[line_number][j] = line[j];
            }
            line_number++;
        }

        inputfile.close();
    }
    else {
        std::cout << "File could not open..." << std::endl;
    }
}
void get_login_button() {
    int i, j;
    std::ifstream inputfile("login-button.txt");
    if (inputfile.is_open()) {
        std::string line;
        int line_number = 0;

        while (getline(inputfile, line) && line_number < login_button_height) {
            for (j = 0; j < line.length() && j < login_button_width; j++) {
                login_button[line_number][j] = line[j];
            }
            line_number++;
        }

        inputfile.close();
    }
    else {
        std::cout << "File could not open..." << std::endl;
    }
}
void get_signup_button() {
    int i, j;
    std::ifstream inputfile("signup-button.txt");
    if (inputfile.is_open()) {
        std::string line;
        int line_number = 0;

        while (getline(inputfile, line) && line_number < login_button_height) {
            for (j = 0; j < line.length() && j < login_button_width; j++) {
                signup_button[line_number][j] = line[j];
            }
            line_number++;
        }

        inputfile.close();
    }
    else {
        std::cout << "File could not open..." << std::endl;
    }
}
void open_loading() {
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    system("cls");
    SetConsoleCP(437);
    SetConsoleOutputCP(437);
    int bar1 = 177, bar2 = 219;


    COORD coord;
    coord.X = 24;
    coord.Y = 13;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "  WinBank";
    

    coord.X = 22;
    coord.Y = 33;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "@ Copyright 2023";
    coord.X = 13;
    coord.Y = 35;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Powered by Jimmisteo | PIRAEUS BANK";
    

    coord.X = 17;
    coord.Y = 17;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    for (int i = 0; i < 25; i++) {
        cout << static_cast<char>(bar1);
    }

    
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);

    for (int i = 0; i < 25; i++) {
        cout << static_cast<char>(bar2);
        Sleep(150);
    }
    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
}
void create_loading() {
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    system("cls");
    SetConsoleCP(437);
    SetConsoleOutputCP(437);
    int bar1 = 177, bar2 = 219;


    COORD coord;
    coord.X = 22;
    coord.Y = 8;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "  WinBank";

    coord.X = 19;
    coord.Y = 11;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Creating your account...";

    coord.X = 13;
    coord.Y = 13;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "- This will only take a few seconds -";

    coord.X = 22;
    coord.Y = 33;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "@ Copyright 2023";
    coord.X = 13;
    coord.Y = 35;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Powered by Jimmisteo | PIRAEUS BANK";


    coord.X = 17;
    coord.Y = 17;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    for (int i = 0; i < 25; i++) {
        cout << static_cast<char>(bar1);
    }


    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);

    for (int i = 0; i < 25; i++) {
        cout << static_cast<char>(bar2);
        Sleep(150);
    }
    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
}
bool login_singup() {
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);

    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO consoleInfo;
    GetConsoleScreenBufferInfo(hConsole, &consoleInfo);
    WORD originalColor = consoleInfo.wAttributes;
    system("cls");
    COORD coord;
    coord.X = 24;
    coord.Y = 9;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "  WinBank";

    coord.X = 23;
    coord.Y = 13;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 0x2F);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 12; j++) {
            cout << login_button[i][j];
        }
    }

    coord.X = 23;
    coord.Y = 19;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 12; j++) {
            cout << signup_button[i][j];
        }
    }
    coord.X = 21;
    coord.Y = 15;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << ">";
    coord.X = 36;
    coord.Y = 15;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << "<";
    char choice;
    bool login_b = true;
    bool signup_b = false;
    coord.X = 22;
    coord.Y = 33;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "@ Copyright 2023";
    coord.X = 13;
    coord.Y = 35;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Powered by Jimmisteo | PIRAEUS BANK";
    do {
        choice = _getch();
        switch (choice) {
        case KEY_UP:if (signup_b == true) {
                        signup_b = false;
                        login_b = true;
                        SetConsoleTextAttribute(hConsole, originalColor);
                        system("cls");
                        coord.X = 24;
                        coord.Y = 9;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        cout << "  WinBank";
                        coord.X = 23;
                        coord.Y = 13;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        SetConsoleTextAttribute(hConsole, 0x2F);
                        for (int i = 0; i < 3; i++) {
                            coord.Y++;
                            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                            for (int j = 0; j < 12; j++) {
                                cout << login_button[i][j];
                            }
                        }

                        coord.X = 23;
                        coord.Y = 19;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        SetConsoleTextAttribute(hConsole, 6);
                        for (int i = 0; i < 3; i++) {
                            coord.Y++;
                            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                            for (int j = 0; j < 12; j++) {
                                cout << signup_button[i][j];
                            }
                        }
                        coord.X = 21;
                        coord.Y = 15;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        SetConsoleTextAttribute(hConsole, originalColor);
                        cout << ">";
                        coord.X = 36;
                        coord.Y = 15;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        SetConsoleTextAttribute(hConsole, originalColor);
                        cout << "<";
                        coord.X = 22;
                        coord.Y = 33;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        cout << "@ Copyright 2023";
                        coord.X = 13;
                        coord.Y = 35;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        cout << "Powered by Jimmisteo | PIRAEUS BANK";
                    }

                   break;
        case KEY_DOWN:if (login_b == true) {
                        signup_b = true;
                        login_b = false;
                        SetConsoleTextAttribute(hConsole, originalColor);
                        system("cls");
                        coord.X = 24;
                        coord.Y = 9;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        cout << "  WinBank";
                        coord.X = 23;
                        coord.Y = 13;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        SetConsoleTextAttribute(hConsole, 6);
                        for (int i = 0; i < 3; i++) {
                            coord.Y++;
                            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                            for (int j = 0; j < 12; j++) {
                                cout << login_button[i][j];
                            }
                        }

                        coord.X = 23;
                        coord.Y = 19;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        SetConsoleTextAttribute(hConsole, 0x2F); 
                        for (int i = 0; i < 3; i++) {
                            coord.Y++;
                            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                            for (int j = 0; j < 12; j++) {
                                cout << signup_button[i][j];
                            }
                        }
                        coord.X = 21;
                        coord.Y = 21;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        SetConsoleTextAttribute(hConsole, originalColor);
                        cout << ">";
                        coord.X = 36;
                        coord.Y = 21;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        SetConsoleTextAttribute(hConsole, originalColor);
                        cout << "<";
                        coord.X = 22;
                        coord.Y = 33;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        cout << "@ Copyright 2023";
                        coord.X = 13;
                        coord.Y = 35;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        cout << "Powered by Jimmisteo | PIRAEUS BANK";
                    }
                     break;
        }
    } while (choice !='\r');
    SetConsoleTextAttribute(hConsole, originalColor);
    return login_b;
}
void login(vector<bank_account> &bank_accounts,int &li,bool &yes) {
    int console_width = 60;
    int console_height = 40;

    HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
    SMALL_RECT rect;
    COORD coordinates;

    rect.Left = 0;
    rect.Top = 0;
    rect.Right = console_width - 1;
    rect.Bottom = console_height - 1;

    SetConsoleWindowInfo(console, TRUE, &rect);

    coordinates.X = console_width;
    coordinates.Y = console_height;
    SetConsoleScreenBufferSize(console, coordinates);

    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO consoleInfo;
    GetConsoleScreenBufferInfo(hConsole, &consoleInfo);
    WORD originalColor = consoleInfo.wAttributes;
    SetConsoleTextAttribute(hConsole, originalColor);

    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    system("cls");  
    COORD coord;
    coord.X = 15;
    coord.Y = 9;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "  WinBank | Login Page";

    coord.X = 12;
    coord.Y = 12;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Email";

    coord.X = 12;
    coord.Y = 18;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Password";

    coord.X = 12;
    coord.Y = 12;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }

    coord.X = 12; 
    coord.Y = 18;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }

    coord.X = 23;
    coord.Y = 24;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 0x2F);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 12; j++) {
            cout << login_button[i][j];
        }
    }


    string usernafme;
    string password;
    coord.X = 22;
    coord.Y = 33;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << "@ Copyright 2023";
    coord.X = 13;
    coord.Y = 35;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Powered by Jimmisteo | PIRAEUS BANK";

    SetConsoleTextAttribute(hConsole, 6);

    coord.X = 14;
    coord.Y = 14;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cin >> usernafme;

    coord.X = 14;
    coord.Y = 20;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cin >> password;

    SetConsoleTextAttribute(hConsole, originalColor);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);

    yes = true;

    coord.X = 12;
    coord.Y = 23;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Remember me";

    coord.X = 26;
    coord.Y = 23;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 0x2F);
    cout << "YES";

    coord.X = 33;
    coord.Y = 23;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << "NO";

    coord.X = 25;
    coord.Y = 23;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << ">";

    coord.X = 29;
    coord.Y = 23;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << "<";

    char rem;
    do {
        coord.X = 25;
        coord.Y = 23;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        rem = _getch();
        if (rem == KEY_RIGHT && yes == true) {
            yes = false;

            system("cls");
            coord.X = 15;
            coord.Y = 9;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "  WinBank | Login Page";

            coord.X = 12;
            coord.Y = 12;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Email";

            coord.X = 12;
            coord.Y = 18;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Password";

            coord.X = 12;
            coord.Y = 12;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            for (int i = 0; i < 3; i++) {
                coord.Y++;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                for (int j = 0; j < 35; j++) {
                    cout << form[i][j];
                }
            }

            coord.X = 12;
            coord.Y = 18;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            for (int i = 0; i < 3; i++) {
                coord.Y++;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                for (int j = 0; j < 35; j++) {
                    cout << form[i][j];
                }
            }

            coord.X = 23;
            coord.Y = 24;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 0x2F);
            for (int i = 0; i < 3; i++) {
                coord.Y++;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                for (int j = 0; j < 12; j++) {
                    cout << login_button[i][j];
                }
            }


            
            coord.X = 22;
            coord.Y = 33;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << "@ Copyright 2023";
            coord.X = 13;
            coord.Y = 35;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Powered by Jimmisteo | PIRAEUS BANK";

            SetConsoleTextAttribute(hConsole, 6);

            coord.X = 14;
            coord.Y = 14;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << usernafme;

            coord.X = 14;
            coord.Y = 20;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << password;

            SetConsoleTextAttribute(hConsole, originalColor);
            cursorInfo.bVisible = false;
            SetConsoleCursorInfo(consoleHandle, &cursorInfo);

            

            coord.X = 12;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Remember me";

            coord.X = 26;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            cout << "YES";

            coord.X = 33;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord); 
            SetConsoleTextAttribute(hConsole, 0x2F);
            cout << "NO";

            coord.X = 32;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << ">";

            coord.X = 35;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << "<";
        }
        else if (rem == KEY_LEFT && yes == false) {
            yes = true;
            system("cls");
            coord.X = 15;
            coord.Y = 9;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "  WinBank | Login Page";

            coord.X = 12;
            coord.Y = 12;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Email";

            coord.X = 12;
            coord.Y = 18;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Password";

            coord.X = 12;
            coord.Y = 12;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            for (int i = 0; i < 3; i++) {
                coord.Y++;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                for (int j = 0; j < 35; j++) {
                    cout << form[i][j];
                }
            }

            coord.X = 12;
            coord.Y = 18;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            for (int i = 0; i < 3; i++) {
                coord.Y++;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                for (int j = 0; j < 35; j++) {
                    cout << form[i][j];
                }
            }

            coord.X = 23;
            coord.Y = 24;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 0x2F);
            for (int i = 0; i < 3; i++) {
                coord.Y++;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                for (int j = 0; j < 12; j++) {
                    cout << login_button[i][j];
                }
            }


            
            coord.X = 22;
            coord.Y = 33;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << "@ Copyright 2023";
            coord.X = 13;
            coord.Y = 35;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Powered by Jimmisteo | PIRAEUS BANK";

            SetConsoleTextAttribute(hConsole, 6);

            coord.X = 14;
            coord.Y = 14;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << usernafme;

            coord.X = 14;
            coord.Y = 20;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << password;

            SetConsoleTextAttribute(hConsole, originalColor);
            cursorInfo.bVisible = false;
            SetConsoleCursorInfo(consoleHandle, &cursorInfo);

            

            coord.X = 12;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Remember me";

            coord.X = 26;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 0x2F);
            cout << "YES";

            coord.X = 33;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            cout << "NO";

            coord.X = 25;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << ">";

            coord.X = 29;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << "<";
        }
    } while (rem != '\r');

    coord.X = 32;
    coord.Y = 23;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << " ";

    coord.X = 35;
    coord.Y = 23;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << " ";

    coord.X = 25;
    coord.Y = 23;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << " ";

    coord.X = 29;
    coord.Y = 23;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << " ";

    coord.X = 21;
    coord.Y = 26;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << ">";

    coord.X = 36;
    coord.Y = 26;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "<";

    coord.X = 4;
    coord.Y = 6;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "!TIP : To re-Type your details press the UP-ARROW";
    SetConsoleTextAttribute(hConsole, originalColor);
    char l;
    bool p_form=false, u_form=false, b_form=true,ufound=false,efound=false;
    do {
        coord.X = 39;
        coord.Y = 26;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        l = _getch();
        switch (l) {
        case KEY_UP:if (b_form == true) {
            
            SetConsoleTextAttribute(hConsole, originalColor);
            system("cls");
            coord.X = 15;
            coord.Y = 9;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "  WinBank | Login Page";

            coord.X = 12;
            coord.Y = 12;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Email";

            coord.X = 12;
            coord.Y = 18;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Password";

            coord.X = 12;
            coord.Y = 12;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            for (int i = 0; i < 3; i++) {
                coord.Y++;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                for (int j = 0; j < 35; j++) {
                    cout << form[i][j];
                }
            }

            coord.X = 12;
            coord.Y = 18;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            for (int i = 0; i < 3; i++) {
                coord.Y++;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                for (int j = 0; j < 35; j++) {
                    cout << form[i][j];
                }
            }

            coord.X = 23;
            coord.Y = 24;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 0x2F);
            for (int i = 0; i < 3; i++) {
                coord.Y++;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                for (int j = 0; j < 12; j++) {
                    cout << login_button[i][j];
                }
            }


           
            coord.X = 22;
            coord.Y = 33;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << "@ Copyright 2023";
            coord.X = 13;
            coord.Y = 35;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Powered by Jimmisteo | PIRAEUS BANK";
            cursorInfo.bVisible = true;
            SetConsoleCursorInfo(consoleHandle, &cursorInfo);
            SetConsoleTextAttribute(hConsole, originalColor);
            coord.X = 10;
            coord.Y = 14;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << ">";

            coord.X = 49;
            coord.Y = 14;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "<";

            SetConsoleTextAttribute(hConsole, 6);
            cursorInfo.bVisible = true;
            coord.X = 14;
            coord.Y = 14;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cin >> usernafme;
            SetConsoleTextAttribute(hConsole, originalColor);
            coord.X = 10;
            coord.Y = 14;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << " ";

            coord.X = 49;
            coord.Y = 14;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << " ";
            SetConsoleTextAttribute(hConsole, originalColor);
            coord.X = 10;
            coord.Y = 20;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << ">";

            coord.X = 49;
            coord.Y = 20;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "<";
            SetConsoleTextAttribute(hConsole, 6);
            
            SetConsoleCursorInfo(consoleHandle, &cursorInfo);
            coord.X = 14;
            coord.Y = 20;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cin >> password;

            SetConsoleTextAttribute(hConsole, originalColor);
            coord.X = 10;
            coord.Y = 20;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << " ";

            coord.X = 49;
            coord.Y = 20;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << " ";
            SetConsoleTextAttribute(hConsole, originalColor);
            cursorInfo.bVisible = false;
            SetConsoleCursorInfo(consoleHandle, &cursorInfo);

            yes = true;
            coord.X = 12;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Remember me";

            coord.X = 26;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 0x2F);
            cout << "YES";

            coord.X = 33;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            cout << "NO";

            coord.X = 25;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << ">";

            coord.X = 29;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << "<";

            
            do {
                coord.X = 25;
                coord.Y = 23;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                rem = _getch();
                if (rem == KEY_RIGHT && yes == true) {
                    yes = false;

                    system("cls");
                    coord.X = 15;
                    coord.Y = 9;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "  WinBank | Login Page";

                    coord.X = 12;
                    coord.Y = 12;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Email";

                    coord.X = 12;
                    coord.Y = 18;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Password";

                    coord.X = 12;
                    coord.Y = 12;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 6);
                    for (int i = 0; i < 3; i++) {
                        coord.Y++;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        for (int j = 0; j < 35; j++) {
                            cout << form[i][j];
                        }
                    }

                    coord.X = 12;
                    coord.Y = 18;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 6);
                    for (int i = 0; i < 3; i++) {
                        coord.Y++;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        for (int j = 0; j < 35; j++) {
                            cout << form[i][j];
                        }
                    }

                    coord.X = 23;
                    coord.Y = 24;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 0x2F);
                    for (int i = 0; i < 3; i++) {
                        coord.Y++;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        for (int j = 0; j < 12; j++) {
                            cout << login_button[i][j];
                        }
                    }



                    coord.X = 22;
                    coord.Y = 33;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, originalColor);
                    cout << "@ Copyright 2023";
                    coord.X = 13;
                    coord.Y = 35;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Powered by Jimmisteo | PIRAEUS BANK";

                    SetConsoleTextAttribute(hConsole, 6);

                    coord.X = 14;
                    coord.Y = 14;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << usernafme;

                    coord.X = 14;
                    coord.Y = 20;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << password;

                    SetConsoleTextAttribute(hConsole, originalColor);
                    cursorInfo.bVisible = false;
                    SetConsoleCursorInfo(consoleHandle, &cursorInfo);



                    coord.X = 12;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Remember me";

                    coord.X = 26;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 6);
                    cout << "YES";

                    coord.X = 33;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 0x2F);
                    cout << "NO";

                    coord.X = 32;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, originalColor);
                    cout << ">";

                    coord.X = 35;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, originalColor);
                    cout << "<";
                }
                else if (rem == KEY_LEFT && yes == false) {
                    yes = true;
                    system("cls");
                    coord.X = 15;
                    coord.Y = 9;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "  WinBank | Login Page";

                    coord.X = 12;
                    coord.Y = 12;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Email";

                    coord.X = 12;
                    coord.Y = 18;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Password";

                    coord.X = 12;
                    coord.Y = 12;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 6);
                    for (int i = 0; i < 3; i++) {
                        coord.Y++;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        for (int j = 0; j < 35; j++) {
                            cout << form[i][j];
                        }
                    }

                    coord.X = 12;
                    coord.Y = 18;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 6);
                    for (int i = 0; i < 3; i++) {
                        coord.Y++;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        for (int j = 0; j < 35; j++) {
                            cout << form[i][j];
                        }
                    }

                    coord.X = 23;
                    coord.Y = 24;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 0x2F);
                    for (int i = 0; i < 3; i++) {
                        coord.Y++;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        for (int j = 0; j < 12; j++) {
                            cout << login_button[i][j];
                        }
                    }



                    coord.X = 22;
                    coord.Y = 33;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, originalColor);
                    cout << "@ Copyright 2023";
                    coord.X = 13;
                    coord.Y = 35;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Powered by Jimmisteo | PIRAEUS BANK";

                    SetConsoleTextAttribute(hConsole, 6);

                    coord.X = 14;
                    coord.Y = 14;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << usernafme;

                    coord.X = 14;
                    coord.Y = 20;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << password;

                    SetConsoleTextAttribute(hConsole, originalColor);
                    cursorInfo.bVisible = false;
                    SetConsoleCursorInfo(consoleHandle, &cursorInfo);


                    
                    coord.X = 12;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Remember me";

                    coord.X = 26;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 0x2F);
                    cout << "YES";

                    coord.X = 33;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 6);
                    cout << "NO";

                    coord.X = 25;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, originalColor);
                    cout << ">";

                    coord.X = 29;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, originalColor);
                    cout << "<";
                }
            } while (rem != '\r');

            coord.X = 32;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << " ";

            coord.X = 35;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << " ";

            coord.X = 25;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << " ";

            coord.X = 29;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << " ";

            coord.X = 21;
            coord.Y = 26;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << ">";

            coord.X = 36;
            coord.Y = 26;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "<";
            
            coord.X = 4;
            coord.Y = 6;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 96);
            cout << "!TIP : To re-Type your details press the UP-ARROW";
            SetConsoleTextAttribute(hConsole, originalColor);
        }
            break;
        case '\r':
            for (int i = 0; i < bank_accounts.size(); i++) {
                if (usernafme != bank_accounts[i].email || password != bank_accounts[i].password) {
                    efound = true;
                    
                }
                else if (usernafme == bank_accounts[i].email && password == bank_accounts[i].password) {
                    efound = false;
                    li = i;
                    break;
                }
            }
            if (efound == true) {
                coord.X = 11;
                coord.Y = 30;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 100);
                cout << "!Wrong Email or Password,try again...";
                l = '1';
            }

        }
    } while (l != '\r');

}
void signup(vector<bank_account> &bank_accounts) {

    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);

    int console_width = 60;
    int console_height = 61;

    HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
    SMALL_RECT rect;
    COORD coordinates;

    rect.Left = 0;
    rect.Top = 0;
    rect.Right = console_width - 1;
    rect.Bottom = console_height - 1;

    SetConsoleWindowInfo(console, TRUE, &rect);

    coordinates.X = console_width;
    coordinates.Y = console_height;
    SetConsoleScreenBufferSize(console, coordinates);
    system("cls");
    COORD coord;
    coord.X = 12;
    coord.Y = 2;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);

    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "  WinBank | Sign-Up Page";

    coord.X = 12;
    coord.Y = 4;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "First Name *";
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }
    coord.X = 12;
    coord.Y = 9;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "Last Name *";
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }
    coord.X = 12;
    coord.Y = 14;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "Email *";
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }
    coord.X = 12;
    coord.Y = 19;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "New Password *";
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }
    coord.X = 12;
    coord.Y = 24;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "Confirm Password *";
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }
    coord.X = 12;
    coord.Y = 29;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "Id Number *";
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }
    coord.X = 12;
    coord.Y = 34;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "AFM *";
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }
    coord.X = 12;
    coord.Y = 39;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "Birth Date *";
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }
    coord.X = 14;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << "00/00/0000";
    
    coord.X = 12;
    coord.Y = 44;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "Monthly Income *";
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }
    SetConsoleTextAttribute(hConsole, 96);
    coord.X = 23;
    coord.Y = 50;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 12; j++) {
            cout << signup_button[i][j];
        }
    }

    coord.X = 22;
    coord.Y = 56;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "@ Copyright 2023";
    coord.X = 13;
    coord.Y = 58;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "Powered by Jimmisteo | PIRAEUS BANK";
    
    string first_name, last_nafme, email, password,new_password, id, afm;
    char date[8];
    int income;
    
    coord.X = 12;
    coord.Y = 1;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);

    coord.X = 14;
    coord.Y = 6;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cin >> first_name;

    coord.X = 14;
    coord.Y = 11;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cin >> last_nafme;
    bool email_found=false;
    do {
        cursorInfo.bVisible = true;
        SetConsoleCursorInfo(consoleHandle, &cursorInfo);
        email_found = false;
        coord.X = 14;
        coord.Y = 16;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        SetConsoleTextAttribute(hConsole, 6);
        cin >> email;
        for (int i = 0; i < bank_accounts.size(); i++) {
            if (bank_accounts[i].email == email) {
                email_found = true;
                cursorInfo.bVisible = false;
                SetConsoleCursorInfo(consoleHandle, &cursorInfo);
                coord.X = 30;
                coord.Y = 14;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 100);
                cout << "Email already exists!";
                Sleep(2500);
                coord.X = 30;
                coord.Y = 14;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 100);
                cout << "                           ";
                coord.X = 14;
                coord.Y = 16;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 6);
                cout << "                                 ";
            }
        }
    } while (email_found == true);

    coord.X = 14;
    coord.Y = 21;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cin >> password;

    bool safme_pass = true;

    do {
        cursorInfo.bVisible = true;
        SetConsoleCursorInfo(consoleHandle, &cursorInfo);
        safme_pass = true;
        coord.X = 14;
        coord.Y = 26;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        SetConsoleTextAttribute(hConsole, 6);
        cin >> new_password;
        if (new_password != password) {
            cursorInfo.bVisible = false;
            SetConsoleCursorInfo(consoleHandle, &cursorInfo);
            safme_pass = false;
            coord.X = 31;
            coord.Y = 24;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 100);
            cout << "Wrong Password!";
            Sleep(2500);
            coord.X = 31;
            coord.Y = 24;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 100);
            cout << "                ";
            coord.X = 14;
            coord.Y = 26;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            cout << "                                 ";

        }
    } while (safme_pass == false);

    coord.X = 12;
    coord.Y = 43;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);

    coord.X = 14;
    coord.Y = 31;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cin >> id;

    bool afm_found=false;

    do {
        cursorInfo.bVisible = true;
        SetConsoleCursorInfo(consoleHandle, &cursorInfo);
        afm_found = false;
        coord.X = 14;
        coord.Y = 36;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        SetConsoleTextAttribute(hConsole, 6);
        cin >> afm;
        for (int i = 0; i < bank_accounts.size(); i++) {
            if (afm == bank_accounts[i].afm) {
                cursorInfo.bVisible = false;
                SetConsoleCursorInfo(consoleHandle, &cursorInfo);
                afm_found = true;
                coord.X = 17;
                coord.Y = 34;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 100);
                cout << "This AFM belongs to another person!";
                Sleep(2500);
                coord.X = 17;
                coord.Y = 34;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 100);
                cout << "                                    ";
                coord.X = 14;
                coord.Y = 36;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 6);
                cout << "                                ";

            }
        }
    } while (afm_found == true);

    coord.X = 12;
    coord.Y = 55;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);

    coord.X = 14;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    date[0] = _getch();
    coord.X = 14;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << date[0];
    coord.X = 15;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    date[1] = _getch();
    coord.X = 15;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << date[1];
    coord.X = 17;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    date[2] = _getch();
    coord.X = 17;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << date[2];
    coord.X = 18;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    date[3] = _getch();
    coord.X = 18;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << date[3];
    coord.X = 20;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    date[4] = _getch();
    coord.X = 20;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << date[4];
    coord.X = 21;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    date[5] = _getch();
    coord.X = 21;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << date[5];
    coord.X = 22;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    date[6] = _getch();
    coord.X = 22;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << date[6];
    coord.X = 23;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    date[7] = _getch();
    coord.X = 23;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << date[7];
   


    coord.X = 14;
    coord.Y = 46;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cin >> income;

    coord.X = 21;
    coord.Y = 60;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);

    coord.X = 21;
    coord.Y = 52;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << ">";
    coord.X = 36;
    coord.Y = 52;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "<";
    char  s;
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    do {
        coord.X = 42;
        coord.Y = 50;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        SetConsoleTextAttribute(hConsole, 96);
        
        s = _getch();

    } while (s!='\r');


    bank_account stud;
    stud.first_name = first_name;
    stud.last_nafme = last_nafme;
    stud.email = email;
    stud.password = password;
    stud.id_number = id;
    stud.afm = afm;
    stud.birth_date = date[0] + date[1] + date[2] + date[3] + date[4] + date[5] + date[6] + date[7] ;
    stud.income = income;
    stud.ects = 0;
    stud.remember = false;
    bank_accounts.push_back(stud);
    save_accounts(bank_accounts);
    SetConsoleTextAttribute(hConsole, 96);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    create_loading();

    system("cls");

    coord.X = 16;
    coord.Y = 10;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "  WinBank";

    coord.X = 8;
    coord.Y = 14;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "Your has been created successfully!";

    for (int i = 0; i < 5; i++) {
        coord.X = 8;
        coord.Y = 16;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        SetConsoleTextAttribute(hConsole, 96);
        cout << "You can login in " << 5 - i << " seconds.";
        Sleep(1000);
    }



}
void save_subjects(const vector<subject>& subjects, const vector<bank_account>& bank_accounts, int li) {
    std::ofstream outfile("subjects.txt");
    if (outfile.is_open()) {
        for (const subject sub : subjects) {

            outfile << bank_accounts[li].email << sub.nafme << "," << sub.mon << "," << sub.s_income << "," << sub.grade <<   "\n";

        }
        outfile.close();
    }
    else {
        std::cout << "Error: Unable to save accounts." << std::endl;
    }
}
void load_subjects(std::vector<subject>& subjects, std::vector<bank_account>& bank_accounts,int li) {
    std::ifstream infile("subjects.txt");
    if (infile.is_open()) {
        std::string line;
        while (std::getline(infile, line)) {
            subject sub("none",1);
            size_t pos = 0;
            std::string token;


            for (int i = 0; i < 6; i++) {
                pos = line.find(",");
                token = line.substr(0, pos);
                switch (i) {
                case 0:
                    bank_accounts[li].email = token;
                    break;
                case 1:
                    sub.nafme = token;
                    break;
                case 2:
                    sub.mon = stoll(token);
                    break;
                case 3:
                    sub.s_income = stoll(token);
                    break;
                case 4:
                    sub.grade = stold(token);
                    break;
                


                }
                line.erase(0, pos + 1);
            }
            subjects.push_back(sub);
        }
        infile.close();
    }
    else {
        std::cout << "Error: Unable to load accounts." << std::endl;
    }
}
void save_accounts(const vector<bank_account>& bank_accounts) {
    std::ofstream outfile("accounts.txt");
    if (outfile.is_open()) {
        for (const bank_account stud : bank_accounts) {

            outfile << stud.first_name << "," << stud.last_nafme << "," << stud.email << "," << stud.password << "," << stud.id_number << "," << stud.afm << "," << stud.birth_date << "," << stud.income << "," << stud.ects << "," << stud.remember <<  "\n";
           


        }
        outfile.close();
    }
    else {
        std::cout << "Error: Unable to save accounts." << std::endl;
    }
}
void load_accounts(std::vector<bank_account>& bank_accounts) {
    std::ifstream infile("accounts.txt");
    if (infile.is_open()) {
        std::string line;
        while (std::getline(infile, line)) {
            bank_account stud;
            size_t pos = 0;
            std::string token;


            for (int i = 0; i < 10; i++) {
                pos = line.find(",");
                token = line.substr(0, pos);
                switch (i) {
                case 0:
                    stud.first_name = token;
                    break;
                case 1:
                    stud.last_nafme = token;
                    break;
                case 2:
                    stud.email = token;
                    break;
                case 3:
                    stud.password = token;
                    break;
                case 4:
                    stud.id_number = token;
                    break;
                case 5:
                    stud.afm = token;
                    break;
                case 6:
                    stud.birth_date = token;
                    break;
                case 7:
                    stud.income = stoll(token);
                    break;
                case 8:
                    stud.ects = stoll(token);
                    break;
                case 9 :
                    stud.remember = (token == "1");
                    break;

                }
                line.erase(0, pos + 1);
            }
            bank_accounts.push_back(stud);
        }
        infile.close();
    }
    else {
        std::cout << "Error: Unable to load accounts." << std::endl;
    }
}
void show_app(vector<bank_account> &bank_accounts,int li) {
    std::transform(bank_accounts[li].first_name.begin(), bank_accounts[li].first_name.end(), bank_accounts[li].first_name.begin(), [](unsigned char c) {
        return std::toupper(c);
        });
    std::transform(bank_accounts[li].last_nafme.begin(), bank_accounts[li].last_nafme.end(), bank_accounts[li].last_nafme.begin(), [](unsigned char c) {
        return std::toupper(c);
        });

    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO consoleInfo;
    GetConsoleScreenBufferInfo(hConsole, &consoleInfo);
    WORD originalColor = consoleInfo.wAttributes;
    SetConsoleTextAttribute(hConsole, originalColor);

    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    system("cls");
    COORD coord;
    coord.X = 3;
    coord.Y = 1;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "You signed in as";
    coord.Y = 2;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << bank_accounts[li].first_name << " " << bank_accounts[li].last_nafme;

    coord.X = 14;
    coord.Y = 3;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 4; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 40; j++) {
            
            cout << " ";
        }
    }
    SetConsoleTextAttribute(hConsole, 96);
    for (int i = 4; i < 8; i++) {
        for (int j = 19; j < 25; j++) {
            coord.X = j;
            coord.Y = i;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            if (i == 5) {
                SetConsoleTextAttribute(hConsole, 6);
            }
            else {
                SetConsoleTextAttribute(hConsole, 96);
            }
            
            cout << " ";
        }
    }

    for (int i = 4; i < 8; i++) {
        for (int j = 31; j < 36; j++) {
            coord.X = j;
            coord.Y = i;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            if (i == 5) {
                SetConsoleTextAttribute(hConsole, 6);
            }
            else {
                SetConsoleTextAttribute(hConsole, 96);
            }

            cout << " ";
        }
    }

    coord.X = 0;
    coord.Y = 5;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << "               ";

    coord.X = 51;
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 4; i++) {
        coord.Y = i;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        cout << " ";
    }

    coord.X = 50;
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 4; i++) {
        coord.Y = i;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        cout << " ";
    }
    
    
    float mo=8;
    coord.X = 16;
    coord.Y = 5;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << mo;
    coord.X = 15;
    coord.Y = 6;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << "M.0";

    coord.X = 27;
    coord.Y = 6;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << bank_accounts[li].ects;
    coord.X = 26;
    coord.Y = 5;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << "ECTS";

    coord.X = 38;
    coord.Y = 5;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << "Passed Subjects";
    coord.X = 45;
    coord.Y = 6;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << "0";

    coord.X = 45;
    coord.Y = 20;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
int main() {
   
    int console_width = 60;   
    int console_height = 40;

    HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
    SMALL_RECT rect;
    COORD coord;

    rect.Left = 0;
    rect.Top = 0;
    rect.Right = console_width - 1;
    rect.Bottom = console_height - 1;

    SetConsoleWindowInfo(console, TRUE, &rect);

    coord.X = console_width;
    coord.Y = console_height;
    SetConsoleScreenBufferSize(console, coord);
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

    SetConsoleTextAttribute(hConsole, 96 );

    get_login_button();
    get_signup_button();
    get_form();
    system("cls");
    open_loading();
    bool foun=false,yes=false;
    int li;
    vector<bank_account> bank_accounts;
    vector<subject> subjects;   
    load_accounts(bank_accounts);

    for (int i = 0; i < bank_accounts.size(); i++) {
        if (bank_accounts[i].remember) {
            foun = true;
            li = i;
            break;
        }
    }
    
    bool log;
    log = login_singup();
    switch (log) {
    case true:if (foun == true) {
                    open_loading();
                    show_app(bank_accounts, li);
              }
              else {
                    login(bank_accounts, li,yes);
                    if (yes == true) {
                        bank_accounts[li].remember = true;
                        for (int i = 0; i < bank_accounts.size(); i++) {
                            if (i != li) {
                                bank_accounts[i].remember = false;
                            }
                        }
                        save_accounts(bank_accounts);
                    }
                    else {
                        bank_accounts[li].remember = false;
                        save_accounts(bank_accounts);
                    }
                    load_subjects(subjects, bank_accounts, li);
                    open_loading();
                    show_app(bank_accounts, li);
              }
              
              break;
    case false:signup(bank_accounts);
               login(bank_accounts, li, yes);
               if (yes == true) {
                   bank_accounts[li].remember = true;
                   save_accounts(bank_accounts);
                   for (int i = 0; i < bank_accounts.size(); i++) {
                       if (i != li) {
                           bank_accounts[i].remember = false;
                       }
                   }
               }
               else {
                   bank_accounts[li].remember = false;
                   save_accounts(bank_accounts);
               }
               load_subjects(subjects, bank_accounts, li);
               open_loading();
               show_app(bank_accounts, li);
               break;
    }
    return 0;

}