#include "subject.h"
#include <ctime>

 subject::subject(std::string s_nafme,int s_sem){
	 nafme = s_nafme;
	 s_income = s_sem;
	 srand(time(NULL));
	 mon = rand() % 3 + 4;
	 grade = rand() % 10;
	}
