#pragma once
#include "bank_account.h"

class subject : public bank_account
{
public:
	std::string nafme;
	int mon;
	int s_income;
	float grade;
	subject(std::string s_nafme, int s_sem);
};

